New-ComplianceSearch -Name "PowerShell Office 365 Book"  -SharePointLocation All  -ExchangeLocation All -ContentMatchQuery "'Apress' AND 'PowerShell'"
