Get-CsExternalAccessPolicy | Select Identity, EnableFederationAccess, EnableXmppAccess, EnablePublicCloudAccess, EnablePublicCloudAudioVideoAccess, EnableOutsideAccess |  Export-csv C:\Apress\Ch05\Policies\externalacess.csv -NoTypeInformation

Get-CsExternalAccessPolicy | Where-Object {$_.EnableFederationAccess -eq $True -and $_.EnablePublicCloudAccess -eq $False}