New-UnifiedGroup -DisplayName "Office 365 Support Community" -Alias o365community -AccessType Public

New-UnifiedGroup -DisplayName "2019 Reorganization" -Alias 2019reorg -AccessType Private

New-UnifiedGroup -DisplayName "Secret Reorganization" -Alias SecretReorg -AccessType Private -HiddenGroupMembershipEnabled