$cred = Get-Credential
Import-Module AzureAD
Import-Module Microsoft.Online.SharePoint.PowerShell
Import-Module SkypeOnlineConnector

$S4B = New-CsOnlineSession -Credential $cred

$Exchange = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri "https://outlook.office365.com/powershell-liveid/" -Credential $cred -Authentication "Basic" -AllowRedirection 

$ComplianceCenter = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://ps.compliance.protection.outlook.com/powershell-liveid/ -Credential $cred -Authentication Basic -AllowRedirection

Import-PSSession $S4B
Import-PSSession $Exchange
Import-PSSession $ComplianceCenter

Connect-AzureAD -Credential $cred
Connect-SPOService -Url https://office365powershell-admin.sharepoint.com  -credential $cred
