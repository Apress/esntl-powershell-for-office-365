New-SPOSite -Url https://office365powershell.sharepoint.com/teams/IT -Owner vlad-admin@office365powershell.ca -StorageQuota 1024  -LocaleID 1033 -Template "STS#0"  -Title "IT Team Site"
