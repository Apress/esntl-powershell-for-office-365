New-PnPWeb -Url Managers -Title "Managers Only Site" -Template "STS#0" -BreakInheritance -Locale 1033 -Description "Use this subsite to communicate about sensitive information between managers"
