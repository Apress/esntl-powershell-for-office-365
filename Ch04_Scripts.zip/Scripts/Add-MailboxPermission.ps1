Add-MailboxPermission -Identity jeff.collins -User vlad-admin@office365powershell.ca -AccessRights FullAccess -InheritanceType All
