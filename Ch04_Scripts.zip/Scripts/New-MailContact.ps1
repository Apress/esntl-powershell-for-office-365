New-MailContact -Name "401K Questions" -ExternalEmailAddress companyname@financialcompany.com 

New-MailContact -Name "Employee Assistance Program" -ExternalEmailAddress companyname@eapprovider.com 
