Remove-CalendarEvents -Identity john.smith@office365powershell.ca -CancelOrganizedMeetings

Remove-CalendarEvents -Identity jeff.collins@office365powershell.ca -CancelOrganizedMeetings -QueryStartDate 1/1/2018 -QueryWindowInDays 30
