$PasswordProfile = New-Object -TypeName Microsoft.Open.AzureAD.Model.PasswordProfile
$PasswordProfile.Password = "Apress2017"
$PasswordProfile.ForceChangePasswordNextLogin = $true
New-AzureADUser -GivenName "Jonathan" -Surname "King" -DisplayName "Jonathan King" -UserPrincipalName "Jonathan@office365powershell.ca" -MailNickName "Jonathan" -AccountEnabled $true -PasswordProfile $PasswordProfile -JobTitle "IT Manager" -Department "IT"
